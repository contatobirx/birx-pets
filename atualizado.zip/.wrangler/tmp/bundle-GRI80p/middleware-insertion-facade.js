				import worker, * as OTHER_EXPORTS from "C:\\Users\\ORBITECH\\Desktop\\orbitek-pets-v2\\.wrangler\\tmp\\pages-Nfcn0y\\functionsWorker-0.8778524632427145.mjs";
				import * as __MIDDLEWARE_0__ from "C:\\Users\\ORBITECH\\AppData\\Local\\npm-cache\\_npx\\32026684e21afda6\\node_modules\\wrangler\\templates\\middleware\\middleware-ensure-req-body-drained.ts";
import * as __MIDDLEWARE_1__ from "C:\\Users\\ORBITECH\\AppData\\Local\\npm-cache\\_npx\\32026684e21afda6\\node_modules\\wrangler\\templates\\middleware\\middleware-miniflare3-json-error.ts";

				export * from "C:\\Users\\ORBITECH\\Desktop\\orbitek-pets-v2\\.wrangler\\tmp\\pages-Nfcn0y\\functionsWorker-0.8778524632427145.mjs";
				const MIDDLEWARE_TEST_INJECT = "__INJECT_FOR_TESTING_WRANGLER_MIDDLEWARE__";
				export const __INTERNAL_WRANGLER_MIDDLEWARE__ = [
					
					__MIDDLEWARE_0__.default,__MIDDLEWARE_1__.default
				]
				export default worker;