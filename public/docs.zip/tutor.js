const elementos = {
  tituloSaudacao: document.getElementById("tituloSaudacao"),
  textoSaudacao: document.getElementById("textoSaudacao"),
  resumo: document.getElementById("resumo"),
  quantidadePets: document.getElementById("quantidadePets"),
  quantidadePerdidos: document.getElementById("quantidadePerdidos"),
  topoPets: document.getElementById("topoPets"),
  carregando: document.getElementById("carregando"),
  listaPets: document.getElementById("listaPets"),
  estadoVazio: document.getElementById("estadoVazio"),
  estadoErro: document.getElementById("estadoErro"),
  textoErro: document.getElementById("textoErro"),
  botaoTentarNovamente: document.getElementById("botaoTentarNovamente"),
  botaoSair: document.getElementById("botaoSair"),
  mensagem: document.getElementById("mensagem"),

  modalEditar: document.getElementById("modalEditar"),
  modalOverlay: document.querySelector("#modalEditar .modal-overlay"),
  fecharModal: document.getElementById("fecharModal"),
  cancelarEdicao: document.getElementById("cancelarEdicao"),
  formEditarPet: document.getElementById("formEditarPet"),

  editarTag: document.getElementById("editarTag"),
  editarNome: document.getElementById("editarNome"),
  editarEspecie: document.getElementById("editarEspecie"),
  editarRaca: document.getElementById("editarRaca"),
  editarSexo: document.getElementById("editarSexo"),
  editarIdade: document.getElementById("editarIdade"),
  editarComportamento: document.getElementById("editarComportamento"),
  editarTutor: document.getElementById("editarTutor"),
  editarWhatsapp: document.getElementById("editarWhatsapp"),
  editarEmail: document.getElementById("editarEmail"),
  editarCep: document.getElementById("editarCep"),
  editarCidade: document.getElementById("editarCidade"),
  editarEstado: document.getElementById("editarEstado"),
  editarEndereco: document.getElementById("editarEndereco"),
};

const estado = {
  pets: [],
  petEmEdicao: null,
  salvando: false,
  buscandoCep: false,
};

function escaparHtml(valor) {
  return String(valor ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function formatarTexto(valor, fallback = "Não informado") {
  const texto = String(valor ?? "").trim();
  return texto || fallback;
}

function somenteNumeros(valor) {
  return String(valor ?? "").replace(/\D/g, "");
}

function valorPet(pet, camel, snake = camel) {
  return pet?.[camel] ?? pet?.[snake] ?? "";
}

function dadosPet(pet) {
  const local = pet?.localizacao ?? {};
  const tutor = pet?.tutor ?? {};

  return {
    tagCodigo: valorPet(pet, "tagCodigo", "tag_codigo"),
    nome: valorPet(pet, "nome"),
    especie: valorPet(pet, "especie"),
    raca: valorPet(pet, "raca"),
    sexo: valorPet(pet, "sexo"),
    idade: valorPet(pet, "idade"),
    comportamento: valorPet(pet, "comportamento"),
    nomeTutor: tutor.nome ?? valorPet(pet, "nomeTutor", "nome_tutor"),
    whatsapp: tutor.whatsapp ?? valorPet(pet, "whatsapp"),
    email: tutor.email ?? valorPet(pet, "email"),
    cep: local.cep ?? valorPet(pet, "cep"),
    logradouro: local.logradouro ?? local.endereco ?? valorPet(pet, "logradouro"),
    cidade: local.cidade ?? valorPet(pet, "cidade"),
    estado: local.estado ?? valorPet(pet, "estado"),
    perdido: Boolean(pet?.perdido),
    fotoUrl: valorPet(pet, "fotoUrl", "foto_url"),
  };
}

function exibirMensagem(texto, tipo = "sucesso") {
  if (!elementos.mensagem) return;

  elementos.mensagem.textContent = texto;
  elementos.mensagem.className =
    tipo === "erro"
      ? "mensagem mensagem-erro"
      : "mensagem mensagem-sucesso";

  clearTimeout(exibirMensagem.temporizador);
  exibirMensagem.temporizador = setTimeout(() => {
    elementos.mensagem.className = "mensagem";
  }, 3500);
}

function definirCarregamento(ativo) {
  if (!elementos.carregando) return;
  elementos.carregando.hidden = !ativo;
  elementos.carregando.style.display = ativo ? "grid" : "none";
}

function montarLocalizacao(petOriginal) {
  const pet = dadosPet(petOriginal);
  const cidade = String(pet.cidade ?? "").trim();
  const uf = String(pet.estado ?? "").trim();

  if (cidade && uf) return `${cidade} - ${uf}`;
  return cidade || uf || "Não informada";
}

function criarCardPet(petOriginal) {
  const pet = dadosPet(petOriginal);
  const especieRaca = [pet.especie, pet.raca].filter(Boolean).join(" • ");
  const tagUrl = encodeURIComponent(pet.tagCodigo);

  const foto = pet.fotoUrl
    ? `<img class="pet-foto" src="${escaparHtml(pet.fotoUrl)}" alt="Foto de ${escaparHtml(pet.nome)}" loading="lazy">`
    : `<div class="pet-sem-foto" aria-hidden="true">🐶</div>`;

  const status = pet.perdido
    ? `<span class="status status-perdido">🔴 Perdido</span>`
    : `<span class="status status-seguro">🟢 Seguro</span>`;

  const classeStatus = pet.perdido ? "botao-seguro" : "botao-alerta";
  const textoStatus = pet.perdido ? "Marcar como encontrado" : "Ativar modo perdido";

  return `
    <article class="pet-card">
      <div class="pet-foto-area">
        ${foto}
        ${status}
      </div>

      <div class="pet-conteudo">
        <div class="pet-titulo">
          <div>
            <div class="pet-nome">${escaparHtml(formatarTexto(pet.nome, "Pet"))}</div>
            <div class="pet-tag">Tag: ${escaparHtml(formatarTexto(pet.tagCodigo, "Não informada"))}</div>
          </div>
        </div>

        <div class="pet-dados">
          <div class="pet-dado">
            <div class="pet-dado-label">Perfil</div>
            <div class="pet-dado-valor">${escaparHtml(formatarTexto(especieRaca))}</div>
          </div>

          <div class="pet-dado">
            <div class="pet-dado-label">Localização</div>
            <div class="pet-dado-valor">${escaparHtml(montarLocalizacao(petOriginal))}</div>
          </div>
        </div>

        <div class="acoes">
          <a class="botao botao-principal" href="/t.html?tag=${tagUrl}" target="_blank" rel="noopener">Ver perfil</a>
          <a class="botao botao-secundario" href="/historico.html?tag=${tagUrl}">Histórico</a>

          <button class="botao botao-editar" type="button" data-acao="editar" data-tag="${escaparHtml(pet.tagCodigo)}">
            Editar informações
          </button>

          <button class="botao ${classeStatus}" type="button" data-acao="modo-perdido" data-tag="${escaparHtml(pet.tagCodigo)}" data-perdido="${pet.perdido ? "1" : "0"}">
            ${textoStatus}
          </button>
        </div>
      </div>
    </article>
  `;
}

function renderizarPets(pets) {
  elementos.listaPets.innerHTML = pets.map(criarCardPet).join("");

  elementos.listaPets.querySelectorAll('[data-acao="modo-perdido"]').forEach((botao) => {
    botao.addEventListener("click", alterarModoPerdido);
  });

  elementos.listaPets.querySelectorAll('[data-acao="editar"]').forEach((botao) => {
    botao.addEventListener("click", abrirModalEdicao);
  });
}

function definirValor(elemento, valor) {
  if (elemento) elemento.value = valor ?? "";
}

function preencherFormulario(petOriginal) {
  const pet = dadosPet(petOriginal);

  definirValor(elementos.editarTag, pet.tagCodigo);
  definirValor(elementos.editarNome, pet.nome);
  definirValor(elementos.editarEspecie, pet.especie);
  definirValor(elementos.editarRaca, pet.raca);
  definirValor(elementos.editarSexo, pet.sexo);
  definirValor(elementos.editarIdade, pet.idade);
  definirValor(elementos.editarComportamento, pet.comportamento);
  definirValor(elementos.editarTutor, pet.nomeTutor);
  definirValor(elementos.editarWhatsapp, pet.whatsapp);
  definirValor(elementos.editarEmail, pet.email);
  definirValor(elementos.editarCep, pet.cep);
  definirValor(elementos.editarCidade, pet.cidade);
  definirValor(elementos.editarEstado, pet.estado);
  definirValor(elementos.editarEndereco, pet.logradouro);
}

function abrirModalEdicao(evento) {
  const tag = evento.currentTarget.dataset.tag;
  const pet = estado.pets.find((item) => String(dadosPet(item).tagCodigo) === String(tag));

  if (!pet) {
    exibirMensagem("Não foi possível localizar este pet.", "erro");
    return;
  }

  if (!elementos.modalEditar || !elementos.formEditarPet) {
    exibirMensagem("O modal de edição não foi encontrado no tutor.html.", "erro");
    return;
  }

  estado.petEmEdicao = pet;
  preencherFormulario(pet);
  elementos.modalEditar.hidden = false;
  document.body.classList.add("modal-aberto");
  setTimeout(() => elementos.editarNome?.focus(), 50);
}

function fecharModalEdicao() {
  if (estado.salvando || !elementos.modalEditar) return;

  elementos.modalEditar.hidden = true;
  document.body.classList.remove("modal-aberto");
  elementos.formEditarPet?.reset();
  estado.petEmEdicao = null;
}

function dadosFormulario() {
  return {
    tagCodigo: elementos.editarTag?.value.trim() ?? "",
    nome: elementos.editarNome?.value.trim() ?? "",
    especie: elementos.editarEspecie?.value.trim() ?? "",
    raca: elementos.editarRaca?.value.trim() ?? "",
    sexo: elementos.editarSexo?.value.trim() ?? "",
    idade: elementos.editarIdade?.value.trim() ?? "",
    comportamento: elementos.editarComportamento?.value.trim() ?? "",
    nomeTutor: elementos.editarTutor?.value.trim() ?? "",
    whatsapp: elementos.editarWhatsapp?.value.trim() ?? "",
    email: elementos.editarEmail?.value.trim() ?? "",
    cep: elementos.editarCep?.value.trim() ?? "",
    cidade: elementos.editarCidade?.value.trim() ?? "",
    estado: elementos.editarEstado?.value.trim().toUpperCase() ?? "",
    logradouro: elementos.editarEndereco?.value.trim() ?? "",
  };
}

function validarFormulario(dados) {
  if (!dados.tagCodigo) return "A tag do pet não foi identificada.";
  if (!dados.nome) return "Informe o nome do pet.";
  if (!dados.nomeTutor) return "Informe o nome do tutor.";

  const telefone = somenteNumeros(dados.whatsapp);
  if (telefone.length < 10 || telefone.length > 13) return "Informe um WhatsApp válido com DDD.";

  if (dados.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(dados.email)) {
    return "Informe um e-mail válido.";
  }

  if (dados.cep && somenteNumeros(dados.cep).length !== 8) {
    return "Informe um CEP válido com 8 números.";
  }

  if (dados.estado && dados.estado.length !== 2) {
    return "Informe o estado usando a sigla com 2 letras.";
  }

  return "";
}

function definirBotaoSalvar(ativo) {
  const botao = elementos.formEditarPet?.querySelector('button[type="submit"]');
  if (!botao) return;

  if (ativo) {
    botao.dataset.textoOriginal = botao.textContent;
    botao.disabled = true;
    botao.textContent = "Salvando...";
  } else {
    botao.disabled = false;
    botao.textContent = botao.dataset.textoOriginal || "Salvar alterações";
  }
}

async function salvarEdicao(evento) {
  evento.preventDefault();
  if (estado.salvando) return;

  const dados = dadosFormulario();
  const erro = validarFormulario(dados);

  if (erro) {
    exibirMensagem(erro, "erro");
    return;
  }

  estado.salvando = true;
  definirBotaoSalvar(true);

  try {
    const resposta = await fetch("/api/tutor-salvar", {
      method: "POST",
      credentials: "same-origin",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify(dados),
    });

    const resultado = await resposta.json().catch(() => ({}));

    if (resposta.status === 401 || resultado.autenticado === false) {
      window.location.replace("/login.html");
      return;
    }

    if (!resposta.ok || !resultado.sucesso) {
      throw new Error(resultado.mensagem || "Não foi possível salvar as informações.");
    }

    exibirMensagem(resultado.mensagem || "Informações atualizadas com sucesso.");
    elementos.modalEditar.hidden = true;
    document.body.classList.remove("modal-aberto");
    estado.petEmEdicao = null;
    await carregarPainel();
  } catch (erroSalvar) {
    console.error("Erro ao salvar:", erroSalvar);
    exibirMensagem(erroSalvar.message || "Não foi possível salvar as informações.", "erro");
  } finally {
    estado.salvando = false;
    definirBotaoSalvar(false);
  }
}

async function buscarCep() {
  if (!elementos.editarCep || estado.buscandoCep) return;

  const cep = somenteNumeros(elementos.editarCep.value);
  if (!cep) return;

  if (cep.length !== 8) {
    exibirMensagem("Informe um CEP válido com 8 números.", "erro");
    return;
  }

  estado.buscandoCep = true;

  try {
    const resposta = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
    const endereco = await resposta.json();

    if (!resposta.ok || endereco.erro) throw new Error("CEP não encontrado.");

    definirValor(elementos.editarEndereco, endereco.logradouro);
    definirValor(elementos.editarCidade, endereco.localidade);
    definirValor(elementos.editarEstado, endereco.uf);
  } catch (erro) {
    exibirMensagem(erro.message || "Não foi possível consultar o CEP.", "erro");
  } finally {
    estado.buscandoCep = false;
  }
}

async function carregarPainel() {
  definirCarregamento(true);
  elementos.estadoErro.hidden = true;
  elementos.estadoVazio.hidden = true;
  elementos.listaPets.innerHTML = "";
  elementos.resumo.hidden = true;
  elementos.topoPets.hidden = true;

  try {
    const resposta = await fetch("/api/tutor", {
      method: "GET",
      credentials: "same-origin",
      headers: { Accept: "application/json" },
    });

    const dados = await resposta.json().catch(() => ({}));

    if (resposta.status === 401 || dados.autenticado === false) {
      window.location.replace("/login.html");
      return;
    }

    if (!resposta.ok || !dados.sucesso) {
      throw new Error(dados.mensagem || "Não foi possível carregar os dados.");
    }

    const pets = Array.isArray(dados.pets) ? dados.pets : [];
    estado.pets = pets;

    const nomeTutor = formatarTexto(dados.tutor?.nome, "Tutor");
    elementos.tituloSaudacao.textContent = `Olá, ${nomeTutor} 👋`;
    elementos.textoSaudacao.textContent =
      pets.length === 1
        ? "Você possui 1 pet cadastrado."
        : `Você possui ${pets.length} pets cadastrados.`;

    elementos.quantidadePets.textContent = String(pets.length);
    elementos.quantidadePerdidos.textContent = String(
      pets.filter((pet) => dadosPet(pet).perdido).length
    );

    elementos.resumo.hidden = false;
    elementos.topoPets.hidden = false;

    if (!pets.length) {
      elementos.estadoVazio.hidden = false;
      return;
    }

    renderizarPets(pets);
  } catch (erro) {
    console.error("Erro ao carregar painel:", erro);
    elementos.textoErro.textContent = erro.message || "Ocorreu um erro inesperado.";
    elementos.estadoErro.hidden = false;
  } finally {
    definirCarregamento(false);
  }
}

async function alterarModoPerdido(evento) {
  const botao = evento.currentTarget;
  const tagCodigo = botao.dataset.tag;
  const novoEstado = botao.dataset.perdido !== "1";

  const confirmar = window.confirm(
    novoEstado
      ? "Deseja ativar o modo perdido para este pet?"
      : "Deseja marcar este pet como encontrado?"
  );

  if (!confirmar) return;

  const textoOriginal = botao.textContent;
  botao.disabled = true;
  botao.textContent = "Atualizando...";

  try {
    const resposta = await fetch("/api/tutor-status", {
      method: "POST",
      credentials: "same-origin",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({ tagCodigo, perdido: novoEstado }),
    });

    const dados = await resposta.json().catch(() => ({}));

    if (resposta.status === 401 || dados.autenticado === false) {
      window.location.replace("/login.html");
      return;
    }

    if (!resposta.ok || !dados.sucesso) {
      throw new Error(dados.mensagem || "Não foi possível atualizar o modo perdido.");
    }

    exibirMensagem(dados.mensagem || "Status atualizado com sucesso.");
    await carregarPainel();
  } catch (erro) {
    exibirMensagem(erro.message || "Não foi possível atualizar o modo perdido.", "erro");
    botao.disabled = false;
    botao.textContent = textoOriginal;
  }
}

async function sair() {
  elementos.botaoSair.disabled = true;
  elementos.botaoSair.textContent = "Saindo...";

  try {
    const resposta = await fetch("/api/logout", {
      method: "POST",
      credentials: "same-origin",
      headers: { Accept: "application/json" },
    });

    const dados = await resposta.json().catch(() => ({}));

    if (!resposta.ok || !dados.sucesso) {
      throw new Error(dados.mensagem || "Não foi possível sair.");
    }

    window.location.replace("/login.html");
  } catch (erro) {
    exibirMensagem(erro.message || "Não foi possível encerrar a sessão.", "erro");
    elementos.botaoSair.disabled = false;
    elementos.botaoSair.textContent = "Sair";
  }
}

function configurarEventos() {
  elementos.botaoTentarNovamente?.addEventListener("click", carregarPainel);
  elementos.botaoSair?.addEventListener("click", sair);
  elementos.fecharModal?.addEventListener("click", fecharModalEdicao);
  elementos.cancelarEdicao?.addEventListener("click", fecharModalEdicao);
  elementos.modalOverlay?.addEventListener("click", fecharModalEdicao);
  elementos.formEditarPet?.addEventListener("submit", salvarEdicao);
  elementos.editarCep?.addEventListener("blur", buscarCep);

  document.addEventListener("keydown", (evento) => {
    if (evento.key === "Escape" && elementos.modalEditar && !elementos.modalEditar.hidden) {
      fecharModalEdicao();
    }
  });
}

configurarEventos();
carregarPainel();
